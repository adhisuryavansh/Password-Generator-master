# Password-Generator
This is a simple Python program with GUI to generate a random password.

<img src="/img1.png" alt="My cool logo"/>
